 <?php 
  include ("../c/c.php");
  include ($nav);
  include ($ailead);
  include ($acontacts);
  ?>
 <?php include ($home_contents_title1);?>
 <?php include ($exp);?>
 <?php include ($home_contents_title2);?>
 <?php include ($peo);?>
 <?php include ($home_center_align);?>
 
<?php include ($ft);?>