
 <?php include ("../c/c.php");?>
 <?php include ("../c/v.php");?>
 <?php include ($nav);?>
 


  
 
<?php include ($ft);?>