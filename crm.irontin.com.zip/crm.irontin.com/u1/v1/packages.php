<div class="menu">

           

   <?php include 'header.php';?>

         

</div>
<style>

body {
                background-color: #ffffff; 
                font-family: Arial;
                font-size: 17px;
                padding: 0px;
            }

</style>           

   
<body >   

<!-- Pricing Section -->
<div class="w3-container w3-center w3-white" style="padding:128px 16px" id="pricing">
  <h3>Our Packages</h3>
  <p class="w3-large">Choose a packing that fits your needs.</p>
  <div class="w3-row-padding" style="margin-top:64px">
    <div class="w3-third w3-section">
      <ul class="w3-ul w3-white w3-hover-shadow">
        <li class="w3-black w3-xlarge w3-padding-32">Freemuim</li>
 
         <li class="w3-padding-16"><b> Cloud Based as Mobile App, Web App, PC App</b>  </li>
         
        <li class="w3-padding-16">Manual Register Products </li>
        <li class="w3-padding-16">Update  & Delete Products</li>
        <li class="w3-padding-16">Inventory Control</li>
        <li class="w3-padding-16">Sales Mangement</li>
          <li class="w3-padding-16">Product Expiry Alert</li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-black w3-padding-large">Sign Up</button>
        </li>
      </ul>
    </div>
    

    
    <div class="w3-third">
      <ul class="w3-ul w3-white w3-hover-shadow">
        <li class="w3-red w3-xlarge w3-padding-48">Premuim Package</li>
        
       <li class="w3-padding-16"> Cloud Based as Mobile App,Web App,PC App  </li>
        
        <li class="w3-padding-16">Auto Register Products</li>
        <li class="w3-padding-16">Update & Delete Products</li>
         <li class="w3-padding-16">Smart Inventory Management</li>
         <li class="w3-padding-16">Products Expiry Indicator Before Expiry</li>
        <li class="w3-padding-16">Search Product By Text Type, Image, QR, and Batch No, Name</li>
        
        <li class="w3-padding-16">Auto Reports of Sales, and GST (Tax) Calculation</li>
        <li class="w3-padding-16">Customers Orders Records</li>
        <li class="w3-padding-16">Customers Lending Records</li>
       <li class="w3-padding-16">Auto Data Backup Per Day</li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-black w3-padding-large">Sign Up</button>
        </li>
      </ul>
    </div>
    <div class="w3-third w3-section">
      <ul class="w3-ul w3-white w3-hover-shadow">
        <li class="w3-black w3-xlarge w3-padding-32">One Time Package</li>
        
        <li class="w3-padding-16"> Cloud Based as Mobile App,Web App,PC App  </li>
        
        <li class="w3-padding-16">Auto Register Products</li>
        <li class="w3-padding-16">Update & Delete Products</li>
         <li class="w3-padding-16">Smart Inventory Management</li>
         <li class="w3-padding-16">Products Expiry Indicator Before Expiry</li>
        <li class="w3-padding-16">Search Product By Text Type, Image, QR, and Batch No, Name</li>
        <li class="w3-padding-16">Products Expiry Indicator</li>
        <li class="w3-padding-16">Auto Reports of Sales, and GST (Tax) Calculation</li>
        <li class="w3-padding-16">Customers Orders Records</li>
        <li class="w3-padding-16">Customers Lending Records</li>
       <li class="w3-padding-16">Auto Data Backup Per Day</li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-black w3-padding-large">Sign Up</button>
        </li>
      </ul>
    </div>
  </div>
</div>






</body>

</html>