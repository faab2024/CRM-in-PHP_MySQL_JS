<?PHP

session_start();
session_destroy();
header("Location:http://crm.regrowup.com/index.php");

?>