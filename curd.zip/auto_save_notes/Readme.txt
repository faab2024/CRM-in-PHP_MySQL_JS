Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/autosave-data-after-specific-time-with-jquery-and-ajax/

### Instructions ###

1. Import attached posts sql files in your database.
2. Update config.php file.