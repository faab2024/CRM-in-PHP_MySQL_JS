
<!doctype html>
<html>
    <head>
        <title></title>
     
        <!-- Script -->
        <script src='https://code.jquery.com/jquery-3.1.1.min.js' type='text/javascript'></script>
   
        
        <script type='text/javascript'>
        $(document).ready(function(){
           var timer;
           var timeout = 1000;  // Timout duration
           $('#postTitle,#postContent,#postCode,#postimgUrl').keyup(function(){
           //$('#postTitle,#postContent').keyup(function(){
                
                if(timer) {
                    clearTimeout(timer);
                }
                timer = setTimeout(saveData, timeout); 
             
           });
                  
           $('#submit').click(function(){
               saveData();
           });
        });

        // Save data
        function saveData(){
            
            var postid = $('#postid').val();
            var title = $('#postTitle').val().trim();
            var imgUrl = $('#postimgUrl').val().trim();
            var code = $('#postCode').val().trim();
            var content = $('#postContent').val().trim();

            if(title != '' || content != ''){
                // AJAX request
                $.ajax({
                    url: 'autosave.php',
                    type: 'post',
                    data: {postid:postid,title:title,content:content,code:code,imgUrl:imgUrl},
                    //data: {postid:postid,title:title,content:content},
                    success: function(response){
                        $('#postid').val(response);
                    }      
                });
            }
            
        }
        
        </script>
    </head>
    <body >
        <input type='text' id='postTitle' placeholder='Enter post title'><br><br>
        <input type='text' id='postimgUrl' placeholder='Enter post title'><br><br>
        <textarea id='postContent' placeholder='Enter content'></textarea><br><br>
        <textarea id='postCode' placeholder='Enter Codes'></textarea><br><br>
        <input type='button' id='submit' value='Submit'>
        <textarea  id='postid' value='0' >0</textarea>
    </body>
</html>